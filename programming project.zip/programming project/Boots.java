/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author lenovo
 */

public class Boots extends FootballShop implements DiscConsiderable {

    private int size;

    public Boots() {

    }

    public Boots(String brand, double price, int quantity, int size) {
        super(brand, price, quantity);
        this.size = size;
    }

    @Override
    public double calcDisk() {
        return getPrice() - RATE * getPrice();
    }

    @Override
    public double CalcPrice() {
        return calcDisk() * getQuantity();
    }

    @Override
    public void display() {
        System.out.println("SOCCER BOOTS ");
        System.out.println("Brand : " + this.getBrand());
        System.out.println("Price : $" + this.getPrice() + " for size " + size);
        System.out.println("Discount : " + RATE * 100 + "%");
        System.out.println("Quantity : " + this.getQuantity());
        System.out.printf("subtotal : $%.2f" , CalcPrice());
        System.out.println("");

    }
    

}
