/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author lenovo
 */
public  class SoccerBall extends FootballShop  {
    private int ballType ; 
public SoccerBall(){

}    

public SoccerBall(String brand , double price , int quantity , int ballType ){
     super(brand , price , quantity ) ;
     this.ballType = ballType ; 
switch(ballType) {
    case 1 :
        setPrice(200) ; 
        break ;
    case 2 :
        setPrice(80) ;
        break ;
    case 3 :
        setPrice(50) ;
        break ;
    case 4 : 
        setPrice(20) ; 
        break ;
    default :
        setPrice(50) ;
}

}    
    @Override
    public double CalcPrice(){
    return getPrice()* getQuantity() ; 
    }
    
    @Override
    public void display() throws NotBallTypeException {
         System.out.println("SOCCER BALL ");
         System.out.println("Brand : " + this.getBrand() );
         NotBallTypeException e = new NotBallTypeException( this.ballType + " Not a valid soccer Ball type , changing the soccer ball type to training ball" );
       try{ 
           
       switch(this.ballType){
        case  1 : {
               System.out.println("Type : Professional Match");
               break ;
       }
        case 2 :
       {
               System.out.println("Type : Match");
               break ; 
       }
        case 3 : 
       {
        System.out.println("Type : Training");
        break ; 
       }
        case 4 :

       {
        System.out.println("Type : Recreational");
        break ;
       }    
        default : 
        { 
         throw e ;         
       }   
       }
       }
           catch(NotBallTypeException e2 ) {
               System.out.println( e.getMessage());
                System.out.println(); 
                System.out.println("SOCCER BALL ");
                System.out.println("Brand : " + this.getBrand() ); 
                System.out.println("Type : Training");

           } 
           System.out.println("Price : $" + getPrice()  );
           System.out.println("No Discount ! ");
           System.out.println("Quantity : " + getQuantity() );     
           System.out.printf("subtotal : $%.2f" , CalcPrice()); 
           System.out.println("");
       
       

    }




}
