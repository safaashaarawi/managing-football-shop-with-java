/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author lenovo
 */
public interface DiscConsiderable {

    double RATE = 0.17;

    public double calcDisk();

}
