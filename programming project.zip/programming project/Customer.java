/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project;

/**
 *
 * @author lenovo
 */
public class Customer {
    
    private String cusName;
    private FootballShop[] itemList = new FootballShop[10];
    private int numOfitems;
    private double totalPay;

    public Customer(String name) {
        this.cusName = name;
        numOfitems = 0;
        totalPay = 0.0;
    }

    public String getName() {
        return cusName;
    }

    public void buy(FootballShop product) throws NotBallTypeException {
        itemList[numOfitems] = product;
        totalPay += product.CalcPrice();
        System.out.println("Item " + (numOfitems+1) );
        product.display();
        System.out.println("");
        numOfitems ++ ; 
    }

    public void print() {
        System.out.printf("Total = $%.2f" , totalPay);
        System.out.println("");
    }

    public int getNumOfitems() {
        return numOfitems;
    }

    public double getTotalPay() {
        return totalPay;
    }

    @Override
    public String toString() {
        return "Welcome " + cusName +  "\n\nList of Football Items Bought\n";

    }

    }
    
    